# LearnCountriesWebApp
Lancer le serveur corese avec le chargement des fichiers du dossier rdf
java -jar corese-server.jar -load fichierN3.nt

Ouvrir cours.html ou exercice.html
